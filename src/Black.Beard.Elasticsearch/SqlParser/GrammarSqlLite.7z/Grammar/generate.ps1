# antlr-4.7-complete.jar must be preset 
# http://www.antlr.org/download/antlr-4.7-complete.jar

java.exe -jar antlr-4.7-complete.jar -Dlanguage=CSharp SQLiteLexer.g4 -visitor -no-listener -package Bb.SQLite.Lexer
java.exe -jar antlr-4.7-complete.jar -Dlanguage=CSharp SQLiteParser.g4 -visitor -no-listener -package Bb.SQLite.Parser
